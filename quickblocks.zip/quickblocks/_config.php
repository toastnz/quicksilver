<?php

define('TOAST_QUICKBLOCKS_DIR', basename(__DIR__));
